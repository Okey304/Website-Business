<?php
// Site configuration
define('SITE_NAME', "Tutor's Lounge");
define('SITE_EMAIL', 'info@tutorslounge.com');
define('BASE_URL', 'http://localhost/tutor');

// Error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);